package com.pelican.gbantitrava;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputFilter;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(12, 16, 15);
    private static final int PANEL = Color.rgb(23, 30, 28);
    private static final int GREEN = Color.rgb(0, 220, 130);
    private static final int TEXT = Color.rgb(235, 245, 240);
    private static final int MUTED = Color.rgb(150, 170, 160);
    private EditText messageInput;
    private TextView result;
    private LinearLayout root;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);

        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(22), dp(20), dp(28));
        root.setBackgroundColor(BG);
        scroll.addView(root);
        setContentView(scroll);

        TextView brand = text("GB  /  ANTI-TRAVA", 25, GREEN, true);
        root.addView(brand);
        TextView subtitle = text("PROTEÇÃO LOCAL • SEM SERVIDOR • SEM CONTAS", 11, MUTED, true);
        subtitle.setPadding(0, dp(5), 0, dp(20));
        root.addView(subtitle);

        LinearLayout status = panel();
        TextView statusTitle = text("●  ESCUDO LOCAL ATIVO", 14, GREEN, true);
        status.addView(statusTitle);
        TextView statusBody = text("Este protótipo analisa o texto que você colar aqui. Ele não se conecta ao WhatsApp nem lê mensagens de outros aplicativos.", 13, TEXT, false);
        statusBody.setPadding(0, dp(8), 0, 0);
        status.addView(statusBody);
        root.addView(status, params(-1, -2, 0, 0, 0, 0, 0, 16));

        root.addView(text("ANALISADOR DE MENSAGENS", 13, GREEN, true));
        messageInput = new EditText(this);
        messageInput.setTextColor(TEXT);
        messageInput.setHintTextColor(MUTED);
        messageInput.setHint("Cole uma mensagem para verificar…");
        messageInput.setGravity(Gravity.TOP | Gravity.START);
        messageInput.setMinLines(4);
        messageInput.setMaxLines(8);
        messageInput.setPadding(dp(13), dp(12), dp(13), dp(12));
        messageInput.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4000)});
        messageInput.setBackground(round(PANEL, 12, Color.rgb(50, 70, 62)));
        root.addView(messageInput, params(-1, -2, 0, 10, 0, 0, 0, 10));

        Button analyze = button("ANALISAR TEXTO");
        root.addView(analyze, params(-1, dp(48), 0, 0, 0, 0, 0, 10));
        result = text("Aguardando análise. Limite de entrada: 4.000 caracteres.", 13, MUTED, false);
        result.setPadding(dp(14), dp(14), dp(14), dp(14));
        result.setBackground(round(PANEL, 10, Color.TRANSPARENT));
        root.addView(result, params(-1, -2, 0, 0, 0, 0, 0, 22));
        analyze.setOnClickListener(v -> analyzeText());

        root.addView(text("RECURSOS DE PROTEÇÃO", 13, GREEN, true));
        addFeature("01", "Limite de entrada", "O campo aceita até 4.000 caracteres para reduzir consumo acidental de recursos.");
        addFeature("02", "Caracteres de controle", "Sinaliza controles invisíveis e marcas direcionais que podem confundir a leitura.");
        addFeature("03", "Repetição excessiva", "Sinaliza padrões muito repetitivos ou texto excepcionalmente longo.");
        addFeature("04", "Privacidade", "A análise é feita no próprio aparelho. O app não solicita permissões de rede, contatos ou SMS.");

        TextView disclaimer = text("IMPORTANTE: isto é um protótipo independente. Não garante imunidade a falhas de outros aplicativos e não impede que mensagens cheguem ao WhatsApp. Não abra nem encaminhe conteúdo suspeito.", 11, MUTED, false);
        disclaimer.setPadding(0, dp(20), 0, 0);
        root.addView(disclaimer);
    }

    private void analyzeText() {
        String s = messageInput.getText().toString();
        if (s.trim().isEmpty()) {
            showResult("INSIRA UM TEXTO", "Cole uma mensagem no campo acima para analisá-la.", MUTED);
            return;
        }
        int flags = 0;
        StringBuilder findings = new StringBuilder();
        if (s.length() > 2500) {
            flags++;
            findings.append("• Texto longo (").append(s.length()).append(" caracteres).\n");
        }
        int controls = 0;
        int directional = 0;
        int unusual = 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if ((Character.isISOControl(c) && c != '\n' && c != '\r' && c != '\t')) controls++;
            if ((c >= 0x202A && c <= 0x202E) || (c >= 0x2066 && c <= 0x2069) || c == 0x200E || c == 0x200F) directional++;
            if (c == '\uFFFD') unusual++;
        }
        if (controls > 0) {
            flags++;
            findings.append("• ").append(controls).append(" caractere(s) de controle.\n");
        }
        if (directional > 0) {
            flags++;
            findings.append("• ").append(directional).append(" marca(s) invisível(is) de direção de texto.\n");
        }
        if (unusual > 0) {
            flags++;
            findings.append("• ").append(unusual).append(" caractere(s) de substituição Unicode.\n");
        }
        int maxRun = 1, run = 1;
        for (int i = 1; i < s.length(); i++) {
            if (s.charAt(i) == s.charAt(i - 1)) run++;
            else run = 1;
            if (run > maxRun) maxRun = run;
        }
        if (maxRun >= 80) {
            flags++;
            findings.append("• Sequência repetida muito longa (").append(maxRun).append(" caracteres iguais).\n");
        }
        if (flags == 0) {
            showResult("NENHUM SINAL SIMPLES DETECTADO", "A análise básica não encontrou os padrões verificados. Isso não prova que o conteúdo é seguro.", GREEN);
        } else {
            showResult("ATENÇÃO • " + flags + " SINAL(IS)", findings.toString() + "\nEvite abrir links ou encaminhar a mensagem. Esta análise é heurística e pode gerar falsos positivos.", Color.rgb(255, 190, 75));
        }
    }

    private void showResult(String title, String body, int color) {
        result.setText(title + "\n\n" + body);
        result.setTextColor(color);
    }

    private void addFeature(String number, String title, String body) {
        LinearLayout card = panel();
        card.setOrientation(LinearLayout.HORIZONTAL);
        TextView n = text(number, 16, GREEN, true);
        n.setPadding(0, 0, dp(14), 0);
        card.addView(n);
        LinearLayout words = new LinearLayout(this);
        words.setOrientation(LinearLayout.VERTICAL);
        words.addView(text(title, 14, TEXT, true));
        TextView desc = text(body, 12, MUTED, false);
        desc.setPadding(0, dp(5), 0, 0);
        words.addView(desc);
        card.addView(words, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(card, params(-1, -2, 0, 9, 0, 0, 0, 0));
    }

    private LinearLayout panel() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(15), dp(15), dp(15), dp(15));
        l.setBackground(round(PANEL, 13, Color.TRANSPARENT));
        return l;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(13);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(Color.rgb(0, 25, 16));
        b.setBackground(round(GREEN, 10, GREEN));
        return b;
    }

    private GradientDrawable round(int color, int radiusDp, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        if (strokeColor != Color.TRANSPARENT) d.setStroke(dp(1), strokeColor);
        return d;
    }

    private LinearLayout.LayoutParams params(int w, int h, int l, int t, int r, int b, int ignored, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(l, t, r, bottom);
        return p;
    }

    private int dp(int n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
}

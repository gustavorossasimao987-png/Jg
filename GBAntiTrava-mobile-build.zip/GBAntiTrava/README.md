# GB Anti-Trava (protótipo Android)

Aplicativo independente com visual preto e verde, inspirado genericamente em modificações antigas de mensageiros.

## O que inclui
- Interface nativa Android em tema escuro/verde.
- Analisador local de texto colado pelo usuário.
- Limite de 4.000 caracteres no campo de análise.
- Sinalização heurística de caracteres de controle, marcas direcionais invisíveis, texto longo e sequências repetidas.
- Sem permissões de rede, contatos, SMS ou acesso a outros aplicativos.

## Limitações importantes
- Não é uma versão modificada do WhatsApp e não usa servidores, APIs ou marcas oficiais.
- Não lê nem protege mensagens recebidas em outros aplicativos.
- Não existe garantia de imunidade universal a “trava-zap”; a análise é básica, heurística e pode errar.
- Não abra nem encaminhe conteúdo suspeito.

## Compilar
1. Instale Android Studio com Android SDK Platform 35 e JDK 17 ou superior.
2. Abra a pasta `GBAntiTrava` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Selecione **Build > Build APK(s)**.
5. O APK de depuração deverá aparecer em `app/build/outputs/apk/debug/app-debug.apk`.

Este ambiente não possui Gradle nem Android SDK instalados, então o APK não pôde ser compilado aqui. O projeto-fonte está pronto para abrir no Android Studio.
